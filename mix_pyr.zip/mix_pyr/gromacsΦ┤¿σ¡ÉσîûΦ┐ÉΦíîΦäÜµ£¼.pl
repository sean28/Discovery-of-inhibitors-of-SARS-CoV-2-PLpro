#!/usr/bin/perl
use utf8;
use warnings;
#use strict;
print  "----------------------- By Sean -----------------------\n";
print  "----- Macau University of Science and Technology -----\n";

use expect;
$timeout = 1;
$exp = Expect->spawn("gmx pdb2gmx -f 6wuu_chaina_prep_edit.pdb -o 6wuu_prep_edit.gro -p 6wuu.top -ignh -his -lys -glu -asp");
$exp->expect($timeout,-re=>"Select the Force Field:");  #Force Field
$exp->send("8\n"); 
$exp->expect($timeout,-re=>"Select the Water Model:");  #Water Model 
$exp->send("1\n");
$exp->expect($timeout,-re=>"Which LYSINE" => sub { $exp->send("1\n"); exp_continue; });      #LYS option
$exp->expect($timeout,-re=>"Which ASPARTIC" => sub { $exp->send("0\n"); exp_continue; });    #ASP option
$exp->expect($timeout,-re=>"Which GLUTAMIC" => sub { $exp->send("0\n"); exp_continue; });    #GLU option
$exp->interact()



